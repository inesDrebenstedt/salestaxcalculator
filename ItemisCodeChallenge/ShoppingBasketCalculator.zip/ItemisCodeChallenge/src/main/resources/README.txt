HOW TO RUN THIS CODE:
---------------------

This code is set up on Java SE 17.
Please make sure you have JUnit 5 installed in the class path of this project.

1. Download Shopingbasket.zip file
2. Import .zip file into your IDE
3. Run the Main.java class via right-click "Run As" -> "Java Application"